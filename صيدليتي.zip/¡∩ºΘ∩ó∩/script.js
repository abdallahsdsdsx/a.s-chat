let lang = "ar";
let drugs = [];
const API_URL = "http://localhost:3000/api/drugs";

// تغيير اللغة
document.getElementById("langBtn").onclick = () => {
  lang = lang === "ar" ? "en" : "ar";
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.getElementById("langBtn").innerText = lang === "ar" ? "English" : "عربي";
  document.getElementById("title").innerText = lang === "ar" ? "💊 صيدليتي | Saydalaty" : "💊 Saydalaty | صيدليتي";
  renderDrugs();
};

// القائمة الجانبية
document.getElementById("menuBtn").onclick = () => {
  document.getElementById("sidebar").classList.add("show");
};
document.getElementById("closeSidebar").onclick = () => {
  document.getElementById("sidebar").classList.remove("show");
};

// رفع ملفات TXT
document.getElementById("fileInput").addEventListener("change", (e) => {
  Array.from(e.target.files).forEach((file) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const lines = event.target.result.trim().split("\n");
      lines.forEach(name => {
        if (!name.trim()) return;
        const drug = {
          name: name.trim(),
          dose: "500 ملغ",
          time: "مرتين يوميًا",
          alt: "",
          notes: "يُؤخذ بعد الأكل"
        };
        drugs.push(drug);
        saveToMongo(drug);
      });
      updateAlternatives(); // توليد بدائل ذكية
      saveToLocal();
      renderDrugs();
    };
    reader.readAsText(file);
  });
});

// بحث مباشر
document.getElementById("searchInput").addEventListener("input", renderDrugs);

// توليد بدائل ذكية
function updateAlternatives() {
  drugs.forEach((drug, index) => {
    const similar = drugs.filter((d, i) =>
      i !== index &&
      d.name.toLowerCase().includes(drug.name.toLowerCase().slice(0, 3))
    ).map(d => d.name);
    drug.alt = similar.length > 0 ? similar.join(", ") : "لا يوجد بديل";
  });
}

// عرض الكروت
function renderDrugs() {
  const container = document.getElementById("drugCardsContainer");
  container.innerHTML = "";
  const query = document.getElementById("searchInput").value.toLowerCase();

  drugs.filter(d =>
    Object.values(d).some(v => v.toLowerCase().includes(query))
  ).forEach((drug, index) => {
    const card = document.createElement("div");
    card.className = "drug-card";
    card.innerHTML = `
      <div class="drug-item"><span class="label">الاسم:</span> ${drug.name || "?"}</div>
      <div class="drug-item"><span class="label">الجرعة:</span> ${drug.dose || "?"}</div>
      <div class="drug-item"><span class="label">الوقت:</span> ${drug.time || "?"}</div>
      <div class="drug-item"><span class="label">البديل:</span> ${drug.alt || "?"}</div>
      <div class="drug-item"><span class="label">ملاحظات:</span> ${drug.notes || "?"}</div>
      <div class="card-actions">
        <button class="edit" onclick="editCard(${index})">✏️ تعديل</button>
        <button class="delete" onclick="deleteCard(${index})">🗑️ حذف</button>
      </div>`;
    container.appendChild(card);
  });
}

// تعديل الكرت
function editCard(index) {
  const d = drugs[index];
  d.name = prompt("الاسم:", d.name) || d.name;
  d.dose = prompt("الجرعة:", d.dose) || d.dose;
  d.time = prompt("الوقت:", d.time) || d.time;
  d.alt = prompt("البديل:", d.alt) || d.alt;
  d.notes = prompt("ملاحظات:", d.notes) || d.notes;
  updateAlternatives();
  saveToLocal();
  renderDrugs();
}

// حذف الكرت
async function deleteCard(index) {
  const id = drugs[index]._id;
  if (id) await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  drugs.splice(index, 1);
  saveToLocal();
  renderDrugs();
}

// حفظ محلي
function saveToLocal() {
  localStorage.setItem("drugs", JSON.stringify(drugs));
}
function loadFromLocal() {
  const saved = localStorage.getItem("drugs");
  if (saved) {
    drugs = JSON.parse(saved);
    renderDrugs();
  }
}

// تحميل من MongoDB
async function loadFromMongo() {
  const res = await fetch(API_URL);
  drugs = await res.json();
  updateAlternatives();
  saveToLocal();
  renderDrugs();
}

// حفظ في MongoDB
async function saveToMongo(drug) {
  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(drug)
  });
}

// تصدير PDF
function exportPDF() {
  const win = window.open('', '', 'width=800,height=600');
  let html = `<html><head><title>تقرير الأدوية</title></head><body>`;
  drugs.forEach(d => {
    html += `<hr><b>الاسم:</b> ${d.name}<br>
             <b>الجرعة:</b> ${d.dose}<br>
             <b>الوقت:</b> ${d.time}<br>
             <b>البديل:</b> ${d.alt}<br>
             <b>ملاحظات:</b> ${d.notes}<br>`;
  });
  html += `</body></html>`;
  win.document.write(html);
  win.document.close();
  win.print();
}

// تشغيل أولي
loadFromLocal();
